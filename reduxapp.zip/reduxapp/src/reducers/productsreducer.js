export default function products(defStore=[],action){
        console.log('Within products reducer !');
    return defStore;

}