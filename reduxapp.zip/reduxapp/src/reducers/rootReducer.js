import { combineReducers } from "redux";
import posts from './postsreducer';
import products from './productsreducer';

export var rootReducer = combineReducers({
    posts,products
});