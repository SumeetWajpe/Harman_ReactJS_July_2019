export default function posts(defStore=[],action){
    console.log('Within posts reducer !');
    return defStore;
}