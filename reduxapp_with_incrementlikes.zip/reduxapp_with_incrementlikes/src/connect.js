import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as allactions from './actions/actionCreator';
import App from './App';

//expose store data as props
function mapStateToProps(storedata){
        return {
            allposts:storedata.posts,
            allproducts:storedata.products
        }
}
//expose action creators as props
function mapDispatchToProps(dispatcherObj){
        return bindActionCreators(allactions,dispatcherObj);
}
export var WrapperApp = connect(mapStateToProps,
    mapDispatchToProps)(App)