export default function products(defStore = [], action) {
    switch (action.type) {
        case 'INCREMENT_LIKES':

            let theIndex = defStore.findIndex(p => p.id == 
                action.prodId);
           
                    return [
                        ...defStore.slice(0,theIndex),
                        {...defStore[theIndex],likes:defStore[theIndex].likes + 1},
                        ...defStore.slice(theIndex+1)
                    ];

        case 'DELETE_PRODUCT':
                console.log('Within products reducer !');
                console.log('ActionTYPE : ' + action.type);
                console.log(action);
                return defStore;   
    
        default:
            return defStore;   
    }
}