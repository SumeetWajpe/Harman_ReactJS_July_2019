
const DELETE_PRODUCT = 'DELETE_PRODUCT';
const INCREMENT_LIKES = 'INCREMENT_LIKES';
const ADD_POST = 'ADD_POST';
const REMOVE_POST = 'REMOVE_POST';

export function DeleteProduct(){
    return {type:DELETE_PRODUCT};
}

export function IncrementLikes(prodId){
    return {type:INCREMENT_LIKES,prodId};
}
export function AddPost(){
    return {type:ADD_POST};
}
export function RemovePost(){
    return {type:REMOVE_POST};
}