import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ShoppingCart } from './components/shoppingcart.component';

export class App extends React.Component {
 render(){
  // console.log(this.props);
  return (
    <div className="container">
        <ShoppingCart {...this.props} />
    </div>
  );
 }
}

export default App;
