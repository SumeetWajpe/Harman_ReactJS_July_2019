import axios from 'axios';

const DELETE_PRODUCT = 'DELETE_PRODUCT';
const INCREMENT_LIKES = 'INCREMENT_LIKES';
const ADD_POST = 'ADD_POST';
const REMOVE_POST = 'REMOVE_POST';


export function DeleteProduct(prodId){
    return {type:DELETE_PRODUCT,prodId};
}

export function IncrementLikes(prodId){
    return {type:INCREMENT_LIKES,prodId};
}
export function AddPost(){
    return {type:ADD_POST};
}
export function RemovePost(){
    return {type:REMOVE_POST};
}

export function FetchProducts(){
    return dispatch => {
        axios.get('https://api.myjson.com/bins/73yat').then(
           (response)=>{
              // console.log(response.data);
               dispatch({type:'FETCH_PRODUCTS',
               productlist:response.data})     
           }       
        )
      };
    
    
    
}