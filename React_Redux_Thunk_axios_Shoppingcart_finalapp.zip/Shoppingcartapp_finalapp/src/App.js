import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ShoppingCart } from './components/shoppingcart.component';

export class App extends React.Component {
  componentDidMount(){
    // call an action creator !
    this.props.FetchProducts();
  }
 render(){
  // console.log(this.props);
  return (
    <div className="container">
        <ShoppingCart {...this.props} />
    </div>
  );
 }
}

// import React from 'react';
// import logo from './logo.svg';
// import './App.css';

// class App extends React.Component{
//   render(){
//     return <h1> Using Create React App !</h1>
//   }
// }

export default App;
