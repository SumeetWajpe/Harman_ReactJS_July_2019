export default function posts(defStore=[],action){
   switch (action.type) {
       case 'ADD_POST':
                console.log('Within posts reducer !');
            console.log('ActionTYPE : ' + action.type);
            console.log(defStore);
            
                // return the updated store data !
                return defStore; 
        case 'REMOVE_POST':
                console.log('Within posts reducer !');
            console.log('ActionTYPE : ' + action.type);
            
                // return the updated store data !
                return defStore; 
       default:        
        return defStore;    
   }
}