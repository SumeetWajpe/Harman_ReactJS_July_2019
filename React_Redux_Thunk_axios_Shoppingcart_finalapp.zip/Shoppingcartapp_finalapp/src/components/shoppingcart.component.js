import React from 'react'
import { Product } from './product.component';

export const ShoppingCart = (props) => {
    let productsToBeCreated = props.allproducts.map(p => <Product key={p.id} prodDetails={p} {...props} />)
    return(  
        <React.Fragment>{/* React.Fragment available in react16  */}
            <div className="jumbotron">
                    <h1>Shopping Cart </h1>  
            </div>           
            <div className="row">
                {productsToBeCreated}
            </div>       
        </React.Fragment>      
    )
}

export default ShoppingCart;